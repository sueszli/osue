/* intmul.h */
# ifndef INTMUL_H /* include guard */
# define INTMUL_H

int main(int arg_c, char *argv[]);

#endif /* INTMUL_H */
