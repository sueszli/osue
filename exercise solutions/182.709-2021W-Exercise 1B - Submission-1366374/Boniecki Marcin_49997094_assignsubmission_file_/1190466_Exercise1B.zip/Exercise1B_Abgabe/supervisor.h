/* supervisor.h */
# ifndef SUPERVISOR_H /* include guard */
# define SUPERVISOR_H

int main(int argc, char *argv[]);

#endif /* SUPERVISOR_H */