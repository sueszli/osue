/* generator.h */
# ifndef GENERATOR_H /* include guard */
# define GENERATOR_H

int main(int argc, char *argv[]);

#endif /* GENERATOR_H */