/* ispalindrom.h */
# ifndef ISPALINDROM_H /* include guard */
# define ISPALINDROM_H

int main(int argc, char *argv[]);

#endif /* ISPALINDROM_H */