//
// Created on 2021-11-04 at 14:04.
// Created by andreasmerckel (coffeecodecruncher@gmail.com)
//

#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>


#ifndef IS_PALINDROM_H
#define IS_PALINDROM_H

#endif //IS_PALINDROM_H
